# -*- coding: utf-8 -*-
"""



"""

from tools.core import Configuration
from ca.core import CertificateAuthority
from server.core import Server
import print_pems as ppems  #a �t� ajout� pour l'impression

RESOURCES_DIR = "resources/"
CA_PRIVATE_KEY_FILENAME = RESOURCES_DIR + "ca-private-key.pem"
CA_PUBLIC_KEY_FILENAME = RESOURCES_DIR + "ca-public-key.pem"
SERVER_PRIVATE_KEY_FILENAME = RESOURCES_DIR + "server-private-key.pem"
SERVER_CSR_FILENAME = RESOURCES_DIR + "server-csr.pem"
SERVER_PUBLIC_KEY_FILENAME = RESOURCES_DIR + "server-public-key.pem"
CA_PASSWORD = # A compl�ter
SERVER_PASSWORD = # A compl�ter

CA_CONFIGURATION = Configuration("FR", "Territoire de Belfort", "Sevenans", "UTBM_CA", "localhost") 
SERVER_CONFIGURATION = Configuration("FR", "Territoire de Belfort", "Sevenans", "UTBM_SER", "localhost") 

# Cr�ation de l'autorit� de certification
certificate_authority = CertificateAuthority(#A�compl�ter) 
    # regardez en haut et ca/core.py

# Cr�ation du server
server =Server(#A� compl�ter) 
    # regardez en haut et server/core.py

# Signature du certificat par l'autorit� de certification
signed_certificate = # A compl�ter regardez ca/core.py et server/core.py

#impression des certificats �compl�ter regardez #print_pems




print("finished ...")