# -*- coding: utf-8 -*-
"""



"""

from flask import Flask

# d�finir le message secret
SECRET_MESSAGE = "hypsilophodon" # A modifier
app = Flask(__name__)


@app.route("/")
def get_secret_message():
    return SECRET_MESSAGE


if __name__ == "__main__":
    # HTTP version
    app.run(debug=True, host="0.0.0.0", port=8081)
    # HTTPS version
    # A compl�ter  : n�cessit� de d�placer les bons fichiers vers ce r�pertoire
   